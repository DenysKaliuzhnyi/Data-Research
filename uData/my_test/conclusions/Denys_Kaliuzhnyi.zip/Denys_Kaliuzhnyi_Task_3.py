# Калюжный Денис Владимирович

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from scipy import stats
import seaborn as sns
import os

sns.set()
path = os.getcwd()
fname = "titanic.csv"
dir_load = f"{path}\dataset\{fname}"
data = pd.read_csv(dir_load, index_col="PassengerId")
print(data)


# 3.1 #################################################################################################

alived_female = data[(data['Survived'] == 1) & (data['Sex'] == 'female')]
print(alived_female.groupby('Name').max())


# 3.2 #################################################################################################
plt.scatter(data['Survived'], data['Pclass'])
# sns.stripplot(data=data, orient='h')

plt.show()